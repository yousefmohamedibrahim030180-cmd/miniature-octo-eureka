const RATING_VALUES=[-100,0,1,2,3,4,5,6,7,8,9,10];
const socket=io({transports:["websocket","polling"],reconnection:true,reconnectionAttempts:Infinity,reconnectionDelay:500,reconnectionDelayMax:3000,timeout:10000});
let mode="create",roomCode="",myId="",myRole="",pc=null,localStream=null,remoteStream=new MediaStream(),timerId=null,selectedRating=null,currentRatingRound=0,roundEnding=false,rtcStarting=false,iceQueue=[];
const $=id=>document.getElementById(id);
const show=id=>document.querySelectorAll(".screen").forEach(s=>s.classList.toggle("active",s.id===id));
const toast=t=>{const x=$("toast");x.textContent=t;x.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>x.classList.remove("show"),2800)};
const esc=t=>{const d=document.createElement("div");d.textContent=t;return d.innerHTML};

document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");mode=b.dataset.mode;$("codeWrap").classList.toggle("hidden",mode!=="join");$("enter").textContent=mode==="create"?"CREATE A ROOM →":"JOIN ROOM →"});
$("theme").onclick=()=>{document.body.classList.toggle("dark");localStorage.theme=document.body.classList.contains("dark")?"dark":"light";$("theme").textContent=document.body.classList.contains("dark")?"☀":"☾"};
if(localStorage.theme==="dark"){document.body.classList.add("dark");$("theme").textContent="☀"}

socket.on("connect",()=>{if(roomCode)$("callStatus").textContent="Realtime connected"});
socket.on("disconnect",()=>{if(roomCode)$("callStatus").textContent="Realtime connection lost — reconnecting…"});
socket.on("connect_error",e=>{if(roomCode)$("callStatus").textContent="Connecting to show server…";console.warn("Socket connection error",e)});

$("enter").onclick=()=>{
 const event=mode==="create"?"room:create":"room:join";
 const payload=mode==="create"?{}:{code:$("code").value.trim()};
 if(mode==="join"&&!payload.code)return toast("Enter the room code first.");
 const button=$("enter");button.disabled=true;button.textContent="CONNECTING…";
 socket.emit(event,payload,async r=>{
  button.disabled=false;button.textContent=mode==="create"?"CREATE A ROOM →":"JOIN ROOM →";
  if(!r?.ok)return toast(r?.error||"Could not connect.");
  roomCode=r.code;myId=r.id;show("show");addSystem(mode==="create"?"Room created. Share the code with your date.":"You joined the room.");
  const mediaOk=await startMedia();
  if(!mediaOk)$("permissionModal").classList.remove("hidden");
 });
};

let rtcConfig=null;
async function getRtcConfig(){if(rtcConfig)return rtcConfig;try{const r=await fetch("/rtc-config",{cache:"no-store"});if(!r.ok)throw Error("RTC config failed");rtcConfig=await r.json()}catch{rtcConfig={iceServers:[{urls:["stun:stun.l.google.com:19302","stun:stun.cloudflare.com:3478"]}]}}return rtcConfig}
function mediaMessage(errors){const names=errors.map(e=>e?.name).filter(Boolean);if(names.includes("NotAllowedError")||names.includes("PermissionDeniedError"))return"صلاحية الكاميرا أو الميكروفون مرفوضة. من إعدادات الموقع اجعل Camera وMicrophone = Allow ثم أعد التحميل.";if(names.includes("NotFoundError"))return"Chrome لا يجد كاميرا أو ميكروفون. تأكد أن الأجهزة متصلة ومفعلة.";if(names.includes("NotReadableError"))return"الكاميرا أو الميكروفون مستخدم من برنامج آخر. أغلق Zoom أو Teams وحاول مرة أخرى.";return"تعذر تشغيل الكاميرا والميكروفون."}
async function startMedia(){
 try{
  const secure=window.isSecureContext||["localhost","127.0.0.1"].includes(location.hostname);
  if(!secure){$("callStatus").textContent="Open the site on HTTPS";toast("افتح الموقع عبر HTTPS حتى تعمل الكاميرا والميكروفون.");return false}
  if(!navigator.mediaDevices?.getUserMedia){toast("المتصفح لا يدعم الكاميرا والميكروفون هنا.");return false}
  let stream=null,errors=[];
  try{stream=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:1280},height:{ideal:720},frameRate:{ideal:30,max:30},facingMode:"user"},audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}})}catch(e){errors.push(e)}
  if(!stream){
   let v=null,a=null;try{v=await navigator.mediaDevices.getUserMedia({video:true})}catch(e){errors.push(e)}try{a=await navigator.mediaDevices.getUserMedia({audio:true})}catch(e){errors.push(e)}
   const tracks=[...(v?.getVideoTracks()||[]),...(a?.getAudioTracks()||[])];if(tracks.length)stream=new MediaStream(tracks);
  }
  if(!stream||!stream.getTracks().length){toast(mediaMessage(errors));$("callStatus").textContent="Camera/microphone unavailable";return false}
  localStream?.getTracks().forEach(t=>t.stop());localStream=stream;$("localVideo").srcObject=localStream;await $("localVideo").play().catch(()=>{});
  const hasVideo=localStream.getVideoTracks().length>0,hasAudio=localStream.getAudioTracks().length>0;
  $("cam").style.opacity=hasVideo?"1":".45";$("mic").style.opacity=hasAudio?"1":".45";$("localOff").style.display=hasVideo?"none":"grid";
  $("callStatus").textContent=hasVideo&&hasAudio?"Camera & microphone ready":hasVideo?"Camera ready — microphone unavailable":"Microphone ready — camera unavailable";
  $("permissionModal").classList.add("hidden");socket.emit("media:ready",{code:roomCode});
  if(pc){syncLocalTracks();if(myRole==="host")await makeOffer()}
  return true;
 }catch(e){console.error(e);toast("حدث خطأ أثناء تشغيل أجهزة الصوت والصورة.");return false}
}
$("allowMedia").onclick=async()=>{const b=$("allowMedia");b.disabled=true;await startMedia();b.disabled=false};

function syncLocalTracks(){if(!pc||!localStream)return;const senders=pc.getSenders();for(const kind of ["audio","video"]){const track=localStream.getTracks().find(t=>t.kind===kind);const sender=senders.find(s=>s.track?.kind===kind||(!s.track&&kind==="audio"&&s._kind===kind));if(sender){sender.replaceTrack(track||null).catch(()=>{})}else if(track){const s=pc.addTrack(track,localStream);s._kind=kind}}}
async function makeOffer(){if(!pc||myRole!=="host"||pc.signalingState!=="stable"||rtcStarting)return;rtcStarting=true;try{const offer=await pc.createOffer({offerToReceiveAudio:true,offerToReceiveVideo:true});await pc.setLocalDescription(offer);socket.emit("webrtc:offer",{code:roomCode,offer:pc.localDescription})}catch(e){console.error("Offer error",e)}finally{rtcStarting=false}}
async function flushIce(){if(!pc?.remoteDescription)return;while(iceQueue.length){const c=iceQueue.shift();try{await pc.addIceCandidate(c)}catch(e){console.warn("ICE candidate",e)}}}
async function ensurePeer(){if(pc)return pc;const cfg=await getRtcConfig();pc=new RTCPeerConnection(cfg);remoteStream=new MediaStream();$("remoteVideo").srcObject=remoteStream;
 if(localStream)syncLocalTracks();
 pc.ontrack=async e=>{if(e.track&&!remoteStream.getTracks().some(t=>t.id===e.track.id))remoteStream.addTrack(e.track);$("remotePlaceholder").style.display=remoteStream.getTracks().length?"none":"grid";$("remoteVideo").muted=false;$("remoteVideo").volume=1;try{await $("remoteVideo").play();$("enableAudio").classList.add("hidden")}catch{$("enableAudio").classList.remove("hidden");$("callStatus").textContent="Video connected — click ENABLE SOUND"}};
 pc.onicecandidate=e=>{if(e.candidate)socket.emit("webrtc:ice",{code:roomCode,candidate:e.candidate})};
 pc.onconnectionstatechange=()=>{if(!pc)return;const s=pc.connectionState;if(s==="connected"){$("callStatus").textContent="Connected — audio & video live";$("enableAudio").classList.add("hidden")}else if(s==="connecting")$("callStatus").textContent="Connecting audio & video…";else if(s==="disconnected"){$("callStatus").textContent="Connection interrupted — reconnecting…"}else if(s==="failed"){$("callStatus").textContent="Connection failed — retrying…";setTimeout(()=>{if(pc?.connectionState==="failed")rebuildPeer()},1000)}};
 pc.oniceconnectionstatechange=()=>{if(pc?.iceConnectionState==="failed")pc.restartIce?.()};
 return pc}
async function rebuildPeer(){try{pc?.close()}catch{}pc=null;iceQueue=[];if(!localStream)return;await ensurePeer();if(myRole==="host")await makeOffer()}

socket.on("room:state",async s=>{if(!roomCode)roomCode=s.code;$("roomCode").textContent=s.code;const me=s.participants.find(p=>p.id===myId);if(me)myRole=me.role;if(s.participants.length===2&&s.started&&localStream)socket.emit("media:ready",{code:roomCode})});
socket.on("media:status",x=>{if(x.count<2)$("callStatus").textContent="Waiting for the other participant…"});
socket.on("webrtc:start",async()=>{if(localStream){await ensurePeer();await makeOffer()}});
socket.on("webrtc:offer",async({offer})=>{try{await ensurePeer();if(!pc)return;await pc.setRemoteDescription(new RTCSessionDescription(offer));await flushIce();const answer=await pc.createAnswer();await pc.setLocalDescription(answer);socket.emit("webrtc:answer",{code:roomCode,answer:pc.localDescription})}catch(e){console.error("Offer handling error",e);$("callStatus").textContent="Could not establish the video call."}});
socket.on("webrtc:answer",async({answer})=>{try{if(!pc)return;await pc.setRemoteDescription(new RTCSessionDescription(answer));await flushIce()}catch(e){console.error("Answer error",e)}});
socket.on("webrtc:ice",async({candidate})=>{if(!candidate)return;if(!pc||!pc.remoteDescription){iceQueue.push(candidate);return}try{await pc.addIceCandidate(new RTCIceCandidate(candidate))}catch(e){console.warn("ICE",e)}});

$("mic").onclick=async()=>{const t=localStream?.getAudioTracks()[0];if(!t){await startMedia();return}t.enabled=!t.enabled;$("mic").textContent=t.enabled?"🎙":"🔇";$("callStatus").textContent=t.enabled?"Microphone on":"Microphone muted"};
$("cam").onclick=async()=>{const t=localStream?.getVideoTracks()[0];if(!t){await startMedia();return}t.enabled=!t.enabled;$("cam").textContent=t.enabled?"📷":"🚫";$("localOff").style.display=t.enabled?"none":"grid"};
$("enableAudio").onclick=async()=>{const v=$("remoteVideo");v.muted=false;v.volume=1;try{await v.play();$("enableAudio").classList.add("hidden");$("callStatus").textContent="Connected — audio & video live"}catch{toast("اضغط على أي مكان في الصفحة ثم جرّب Enable Sound مرة أخرى.")}};
$("end").onclick=()=>{if(roundEnding)return;roundEnding=true;$("end").disabled=true;$("callStatus").textContent="Ending round…";socket.emit("round:end",{code:roomCode},r=>{if(!r?.ok){roundEnding=false;$("end").disabled=false;toast(r?.error||"Could not end the round.")}})};

function addSystem(t){const d=document.createElement("div");d.className="msg system";d.innerHTML=`<div class="bubble">${esc(t)}</div>`;$("messages").appendChild(d);$("messages").scrollTop=99999}
socket.on("chat:message",m=>{const d=document.createElement("div");d.className="msg "+(m.id===myId?"me":"");d.innerHTML=`<strong>${m.id===myId?"You":esc(m.label||"Your date")}</strong><div class="bubble">${esc(m.text)}</div><time>${new Date(m.time).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}</time>`;$("messages").appendChild(d);$("messages").scrollTop=99999});
function sendChat(){const t=$("chatText").value.trim();if(t)socket.emit("chat:send",{code:roomCode,text:t},r=>{if(r?.ok)$("chatText").value=""})}$('sendChat').onclick=sendChat;$('chatText').onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendChat()}};socket.on('chat:typing',x=>$('typing').textContent=x.typing?`${x.label||"Your date"} is typing...`:"");let typingTimer;$('chatText').oninput=()=>{socket.emit('chat:typing',{code:roomCode,typing:true});clearTimeout(typingTimer);typingTimer=setTimeout(()=>socket.emit('chat:typing',{code:roomCode,typing:false}),700)};

socket.on("show:stage",d=>{roundEnding=false;$("end").disabled=false;$("ratingModal").classList.add("hidden");show("show");$("stageName").textContent=`ROUND ${d.stage+1} · ${d.data.name}`;$("question").textContent=d.data.question;runTimer(d.endsAt)});
function runTimer(end){clearInterval(timerId);const tick=()=>{const left=Math.max(0,end-Date.now()),sec=Math.ceil(left/1000),m=Math.floor(sec/60),s=sec%60;$("timer").textContent=`${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;$("progress").style.width=`${Math.min(100,100-left/(7*60*1000)*100)}%`;if(!left)clearInterval(timerId)};tick();timerId=setInterval(tick,250)}
socket.on("show:waitingForHost",d=>{$("stageName").textContent=`ROUND ${d.round} · WAITING FOR HOST`;$('question').textContent="The host will send the next question shortly.";clearInterval(timerId);$('timer').textContent="--:--";$('progress').style.width="0%";$('end').disabled=false;roundEnding=false;show("show")});
socket.on("round:ended",x=>{$("callStatus").textContent=x.reason||"Round ended"});

const ratingSelect=$("ratingSelect");
socket.on("show:rating",d=>{currentRatingRound=Number(d.round)||Number(d.stage)+1;roundEnding=true;$('ratingModal').classList.remove('hidden');$('ratingRound').textContent=d.reason?"ROUND ENDED":`ROUND ${d.round} COMPLETE`;$('ratingIntro').textContent="Choose a number from -100 to 10. Your rating is private until the end.";$('ratingStatus').textContent="";$('ratingComment').value="";ratingSelect.value="";$('sendRating').disabled=false;clearInterval(timerId);$('end').disabled=true;selectedRating=null});
$('sendRating').onclick=()=>{const rating=Number(ratingSelect.value);if(!RATING_VALUES.includes(rating))return toast("Choose a rating from -100 to 10.");$('sendRating').disabled=true;socket.emit('show:rating',{code:roomCode,rating,comment:$('ratingComment').value.trim(),round:Number($('ratingRound').textContent.match(/\d+/)?.[0]||0)},r=>{if(r?.ok){$('ratingStatus').textContent="Rating submitted — waiting for your date…"}else{$('sendRating').disabled=false;toast(r?.error||"Could not submit rating.")}})};
socket.on('show:ratingStatus',x=>{if(x.count===2)$('ratingStatus').textContent="Both ratings received. Moving to the next round…"});

let pendingFinalResult=null;
socket.on('show:ratingsSummary',r=>{$('otherRatingTitle').textContent="YOUR DATE'S RATINGS";const rounds=Array.isArray(r.rounds)?r.rounds:[];$('otherStars').innerHTML=rounds.length?rounds.map(x=>`<div class="rating-summary-row"><strong>ROUND ${x.round}</strong><span>${x.rating===null?"—":Number(x.rating)}</span></div>`).join(""):"<p>No ratings received.</p>";$('otherComment').textContent=rounds.filter(x=>x.comment).map(x=>`Round ${x.round}: ${x.comment}`).join("\n");$('ratingsResultModal').classList.remove('hidden')});
socket.on('show:result',r=>{if(r.ratingsReady){pendingFinalResult=r;return}showResult(r)});function showResult(r){$('resultIcon').textContent=r.match?"♥":"♡";$('resultTitle').textContent=r.match?"IT'S A MATCH! ♥":"THANKS FOR BEING HONEST.";$('resultText').textContent=r.match?"You both chose to meet again. The story continues.":"Not every connection is a match — and that's okay.";show('result')}
$('closeRatings').onclick=()=>{$('ratingsResultModal').classList.add('hidden');if(pendingFinalResult){const r=pendingFinalResult;pendingFinalResult=null;showResult(r)}};
socket.on('show:final',()=>{$('ratingModal').classList.add('hidden');show('final')});
function choice(c){socket.emit('show:choice',{code:roomCode,choice:c},r=>{if(r?.ok){$('yes').disabled=true;$('no').disabled=true;$('choiceWait').textContent="Choice locked — waiting for your date…"}else toast(r?.error||"Could not save choice.")})}$('yes').onclick=()=>choice('yes');$('no').onclick=()=>choice('no');
$('copy').onclick=async()=>{try{await navigator.clipboard.writeText(roomCode);toast('Room code copied.')}catch{toast(roomCode)}};$('again').onclick=()=>location.reload();socket.on('room:left',()=>{$('remotePlaceholder').style.display='grid';$('callStatus').textContent='Your date left the room.'});window.addEventListener('beforeunload',()=>{if(roomCode)socket.emit('room:leave',{code:roomCode})});
