# Blind Date Show — Fixed V12

This version fixes the live issues in the Railway/Node version:
- END now ends the current round and opens the private rating dialog; it no longer closes the WebRTC call.
- Ratings are accepted once per round and the next round waits for the host.
- WebRTC signaling is more robust, remote audio/video tracks are combined correctly, and an ENABLE SOUND fallback is shown when browser autoplay blocks audio.
- Camera/microphone acquisition first tries both devices together, then falls back independently if one device fails.
- Socket connection/reconnection status is surfaced instead of leaving the UI apparently frozen.
- Existing Host Control URL remains `/control`.

Run locally: `npm install` then `npm start`.
Railway start command: `npm start`.
Default host key: `BlindDateHost-2026-Secret-8472` (set `ADMIN_KEY` in Railway Variables for production).
